<?php
session_start();
$aid = $_SESSION['id'];
require_once("includes/config.php");

if (!empty($_POST["roomno"])) {
    $roomno = $_POST["roomno"];

    // Assuming the maximum seat limit for a room is 50 (you can replace it with the actual limit)
    $maxSeatLimit = 50;

    $result = "SELECT count(*) FROM registration WHERE roomno=?";
    $stmt = $mysqli->prepare($result);
    $stmt->bind_param('i', $roomno);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count >= $maxSeatLimit) {
        echo "<span style='color:red'>Room Full. Seats are already full for room $roomno.</span>";
    } else {
        echo "<span style='color:green'>Seats are Available in room $roomno.</span>";
    }
}

if (!empty($_POST["oldpassword"])) {
    $pass = $_POST["oldpassword"];
    $result = "SELECT password FROM userregistration WHERE password=?";
    $stmt = $mysqli->prepare($result);
    $stmt->bind_param('s', $pass);
    $stmt->execute();
    $stmt->bind_result($result);
    $stmt->fetch();
    $opass = $result;
    if ($opass == $pass)
        echo "<span style='color:green'> Password matched.</span>";
    else
        echo "<span style='color:red'> Password Not matched</span>";
}
?>
