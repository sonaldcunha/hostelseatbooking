<?php
require_once("includes/config.php");

function getAvailableSeats($roomNo)
{
    global $mysqli;
    $result = "SELECT count(*) FROM registration WHERE roomno=?";
    $stmt = $mysqli->prepare($result);
    $stmt->bind_param('i', $roomNo);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    return $count;
}

if (!empty($_POST["emailid"])) {
    // Your existing email validation code
    // ...
}

if (!empty($_POST["oldpassword"])) {
    // Your existing password validation code
    // ...
}

if (!empty($_POST["roomno"])) {
    $roomno = $_POST["roomno"];

    // Check if room exists
    $roomCheck = "SELECT seater FROM rooms WHERE room_no=?";
    $stmtRoomCheck = $mysqli->prepare($roomCheck);
    $stmtRoomCheck->bind_param('i', $roomno);
    $stmtRoomCheck->execute();
    $stmtRoomCheck->bind_result($seater);
    $stmtRoomCheck->fetch();
    $stmtRoomCheck->close();

    if ($seater > 0) {
        // Room exists, get available seats
        $totalSeats = $seater;
        $occupiedSeats = getAvailableSeats($roomno);
        $availableSeats = $totalSeats - $occupiedSeats;

        if ($occupiedSeats >= $totalSeats) {
            echo "<span style='color:red'> All seats in Room $roomno are occupied.</span>";
        } else {
            echo "<span style='color:green'> $availableSeats seats available in Room $roomno.</span>";
        }
    } else {
        echo "<span style='color:red'> Room $roomno does not exist.</span>";
    }
}
?>
